def recursionFibonacci(num):
         fibonacciList = []
         for i in range(num):
                 fibonacciList.append((i + 1) if i < 2 else sum(fibonacciList[-2:]))
         return fibonacciList
print (recursionFibonacci(100)) 