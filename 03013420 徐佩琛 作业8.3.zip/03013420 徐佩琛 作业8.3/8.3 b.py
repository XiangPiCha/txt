def recurrenceFibonacci(num):
         return num if num < 3 else (recurrenceFibonacci(num - 1) + recurrenceFibonacci(num - 2))
