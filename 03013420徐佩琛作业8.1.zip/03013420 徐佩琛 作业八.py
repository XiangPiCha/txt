
count = 1
 
def test(num, src, dst, rest):
    global count
    if num < 1:
       exit
    elif num == 1:
         print ("%d:\t%s -> %s" % (count, src, dst))
         count += 1
    elif num > 1:
        test(num - 1, src, rest, dst)
        test(1, src, dst, rest)
        test(num - 1, rest, dst, src)
 
if __name__=="__main__":
     test(7, 'A', 'C', 'B')