#!/usr/bin python
#-*-coding:utf-8-*-
def data_year(data_string):
        if (data_string%400==0) or ((data_string%4==0) and (data_string%100!=0)):
                print ("%d leapyear"% data_string)
        else:
                print ("%d noleapyear"% data_string)
                
if __name__=="__main__":
        data_string = int(input("Please input year:"))
        data_year(data_string) 
                